export interface LoginData {
  userId: string;
  password: string;
}

export interface LoginFormData{ 
  id: string; 
  pw: string ;
}