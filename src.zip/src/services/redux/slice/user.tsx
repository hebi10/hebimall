import { createSlice } from '@reduxjs/toolkit';
import { useEffect } from 'react';
import { User } from '../type';

const initialState: User = {
  user: {
    userId: null,
    password: null,
    nickname: null,
    role: null,
  }
}

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    getMydata: (state, action) => {

    },
    login: (state, action) => {
      state.user.userId = action.payload;
    },
  },
});

useEffect(() => {}, [initialState])

export const { getMydata, login } = userSlice.actions;

export default userSlice.reducer;