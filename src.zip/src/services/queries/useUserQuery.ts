import { useQuery } from '@tanstack/react-query';
import { instance as axios, login } from '../api';
import useDecodedToken from "../../hooks/useDecodedToken";
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { UserData } from './type';
import { Credentials } from '../type';

export const useUserQuery = () => {
  const decodedToken = useDecodedToken();
  const navigate = useNavigate();

  const result = useQuery<UserData, Error>({
    queryKey: ['user'],
    queryFn: async () => {
      if (!decodedToken) {
        throw new Error('Token is not available');
      }
      const { data } = await axios.get(`/users/${decodedToken.userId}`);
      return data;
    },
    enabled: !!decodedToken,
    refetchOnWindowFocus: false,
    staleTime: 1000 * 30,
    placeholderData: {
      id: '업데이트 중',
      name: '업데이트 중',
    } as UserData,
  });

  useEffect(() => {
    if (result.isSuccess && result.data) {
      navigate('/me');
    }
  }, [result.isSuccess, result.data, navigate]);

  useEffect(() => {
    if (result.isError) {
      console.error('Failed to fetch user data:', result.error);
    }
  }, [result.isError, result.error]);

  return result;
};